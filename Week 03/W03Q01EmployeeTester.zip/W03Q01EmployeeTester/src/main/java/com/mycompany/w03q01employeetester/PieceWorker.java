/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03q01employeetester;

/**
Create a subclass PieceWorker extending the above Employee class. 
The class PieceWorker should have private instance variables wage (to store the 
* employee’s wage per piece) and pieces (to store the number of pieces produced); 
* appropriate constructor, get and set methods; an overridden toString method; 
* concrete implementation of method earnings to calculate and return the 
* PieceWorker’s  earnings  (wage X pieces).
 */
public class PieceWorker extends Employee
{
    private double wagePerPiece;
    private int pieces;

    public PieceWorker() 
    {
        this ("", "", "", 0.0, 0);
    }

    public PieceWorker(String firstName, String lastName, String socialSecurityNumber, 
                       double wagePerPiece, int pieces) 
    {
        super(firstName, lastName, socialSecurityNumber);
        
        this.wagePerPiece = wagePerPiece;
        this.pieces       = pieces;
    }

    public double getWagePerPiece() {
        return wagePerPiece;
    }

    public int getPieces() {
        return pieces;
    }

    public void setWagePerPiece(double wagePerPiece) {
        this.wagePerPiece = wagePerPiece;
    }

    public void setPieces(int pieces) {
        this.pieces = pieces;
    }

    @Override
    public String toString() {
        /*
        return super.toString() + 
               "PieceWorker{" + "wagePerPiece=" + wagePerPiece + 
               ", pieces=" + pieces + '}';
        */
        return super.toString()                              + " " +
               "$" + String.format ("%,10.2f", wagePerPiece) + " " +
               String.format ("%4d",    pieces)              + " " +
               "$" + String.format ("%,10.2f", earnings() );
    }
    
    public double earnings ()
    {
        return wagePerPiece * pieces;
    }
}
