/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03q01employeetester;

/**
1.	Define an Employee Class. The Employee class should have three instance variables 
* namely firstName, lastName and socialSecurityNumber; appropriate constructor, get and set methods; 
* an overridden toString method; and an abstract method earnings to return a double value.
 */
public abstract class Employee 
{
    private String firstName;
    private String lastName;
    private String socialSecurityNumber;

    public Employee() 
    {
        this ("", "", "");
    }

    public Employee(String firstName, String lastName, String socialSecurityNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setSocialSecurityNumber(String socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }

    @Override
    public String toString() {
        /*
        return "Employee{" + 
               "firstName=" + firstName + 
               ", lastName=" + lastName + 
               ", socialSecurityNumber=" + socialSecurityNumber + '}';\
        */
        return String.format ("%-20s", getClass().getSimpleName() ) + " " +
               String.format ("%-30s", firstName + " " + lastName)  + " " +
               String.format ("%-10s", socialSecurityNumber);
    }
    
    public abstract double earnings ();
    
}
