/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03q01employeetester;

/**
 *
 * @author omalleym
 */
public class SalariedEmployee extends Employee
{
    private double weeklySalary;

    public SalariedEmployee() 
    {
        this ("", "", "", 0.0);
    }

    public SalariedEmployee(String firstName, String lastName, String socialSecurityNumber, double weeklySalary)
    {
        super(firstName, lastName, socialSecurityNumber);
        
        this.weeklySalary = weeklySalary;
    }

    public double getWeeklySalary() {
        return weeklySalary;
    }

    public void setWeeklySalary(double weeklySalary) {
        this.weeklySalary = weeklySalary;
    }
    
    public double earnings ()
    {
        return weeklySalary;
    }

    @Override
    public String toString() {
        //return "SalariedEmployee{" + "weeklySalary=" + weeklySalary + '}';
        return  super.toString()                              + " " +
                String.format ("%15s", " ")                   + "  " +
                "$" + String.format ("%,10.2f", earnings() );
    }
    
    
    
}
