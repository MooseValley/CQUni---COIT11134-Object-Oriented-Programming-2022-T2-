/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03q01employeetester;

/**
 *
 * @author omalleym
 */
public class CasualEmployee extends SalariedEmployee // should be Employee, but we want a 3 level hierarchy for fun
{
    public static final double OVERTIME_THRESHOLD = 38.0;
    public static final double OVERTIME_BONUS     = 1.5;
    
    private double hourlyRate;
    private double hoursWorked;

    public CasualEmployee() {
    }

    public CasualEmployee(String firstName, String lastName, String socialSecurityNumber, double hourlyRate, double hoursWorked) 
    {
        super(firstName, lastName, socialSecurityNumber, 0.0);
        
        this.hourlyRate  = hourlyRate;
        this.hoursWorked = hoursWorked;        
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }
    
    @Override
    public double earnings()
    {
        double result = 0.0;
        
        if (hoursWorked <= OVERTIME_THRESHOLD)
        {
            result = hoursWorked * hourlyRate;
        }
        else
        {
            result = OVERTIME_THRESHOLD * hourlyRate + 
                     (hoursWorked - OVERTIME_THRESHOLD) * OVERTIME_BONUS * hourlyRate;
        }
        
        return result;
    }

    @Override
    public String toString() {
        //return "CasualEmployee{" + "hourlyRate=" + hourlyRate + ", hoursWorked=" + hoursWorked + '}';
        return  super.toString();
               //String.format ("%15s", " ")                   + "  " +
                //"$" + String.format ("%,10.2f", earnings() );
    }
    
    
    
    
}
