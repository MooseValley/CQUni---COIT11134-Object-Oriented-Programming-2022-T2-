/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03q01employeetester;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class EmployeeTester 
{
    public static void main (String[] args)
    {
        //Employee e01 = new Employee ();  // ERROR
        //Employee e02 = new Employee ("Mike", "O", "12345");  // ERROR
    
        /*
        // *** Array
        
        Employee[] employees = new Employee [10];
        
        //employees [0] = new Employee ();  // ERROR
        //employees [0] = new Employee ("Mike", "O", "12345");  // ERROR
        
        employees [0] = new PieceWorker      ("Mike",    "O",     "12345",    5.55, 300);
        employees [1] = new PieceWorker      ("Frankie", "Hound", "445566",   6.77, 295);
        employees [2] = new PieceWorker      ("Bella",   "O",     "778899", 156.77,   7);
        employees [3] = new SalariedEmployee ("Patty",   "O",     "987654", 456.77);
        
        for (int k = 0; k < employees.length; k++)
        {
            if (employees [k] != null)
                System.out.println (employees [k].toString() );
        }
        
        
        // Total up the salary for all Employees in the array
        double totalSalary = 0.0;
        for (Employee e : employees)
        {
            if (e != null)
                totalSalary += e.earnings();
        }
        System.out.println ("Total Salary = $" + String.format ("%,.2f", totalSalary) );
        
        */
        
        
        // *** ArrayList
        // add, size, get, remove, clear, set, ....
        
        // Linked Lists, Stacks, Queues, Trees ... 
        
        ArrayList<Employee> employees = new ArrayList <>();
        
        //employees [0] = new Employee ();  // ERROR
        //employees [0] = new Employee ("Mike", "O", "12345");  // ERROR
        
        employees.add (new PieceWorker      ("Mike",    "O",     "12345",    5.55, 300) );
        employees.add (new PieceWorker      ("Frankie", "Hound", "445566",   6.77, 295) );
        employees.add (new PieceWorker      ("Bella",   "O",     "778899", 156.77,   7) );
        employees.add (new SalariedEmployee ("Patty",   "O",     "987654", 456.77) );
        employees.add (new CasualEmployee   ("Beau",    "Endev", "665544", 19.99, 39.0) );
        
        for (int k = 0; k < employees.size(); k++)
        {
            //if (employees.get(k) != null)
                System.out.println (employees.get(k).toString() );
        }
        
        
        // Total up the salary for all Employees in the array
        double totalSalary = 0.0;
        for (Employee e : employees)
        {
            //if (e != null)
                totalSalary += e.earnings();
        }
        System.out.println ("Total Salary = $" + String.format ("%,.2f", totalSalary) );        
        
        
        // Output SalariedEmployee's only (and their child class objects)
        System.out.println ("*** SalariedEmployee's only:");
        for (int k = 0; k < employees.size(); k++)
        {
            if (employees.get(k) instanceof SalariedEmployee)
                System.out.println (employees.get(k).toString() );
        }
        
        // Total up the salary for all SalariedEmployee's in the array
        double totalSalariedEmployeeSalary = 0.0;
        for (Employee e : employees)
        {
            if (e instanceof SalariedEmployee) //&&
                //!(e instanceof CasualEmployee) )
                totalSalariedEmployeeSalary += e.earnings();
        }
        System.out.println ("Total Salary for SalariedEmployee's = $" + String.format ("%,.2f", totalSalariedEmployeeSalary) );        

        
    }
    
    
}
