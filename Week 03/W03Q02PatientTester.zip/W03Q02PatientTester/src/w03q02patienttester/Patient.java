/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w03q02patienttester;

/**
 *
 * @author omalleym
 */
public abstract class Patient 
{
    private String name;
    //private type Attribute 2
    //private type Attribute 3
    
    
    public String getName()
    {
        return name;
    }
    
    public abstract void operation2 ();
}
