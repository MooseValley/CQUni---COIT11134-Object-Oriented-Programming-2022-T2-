/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w03q02patienttester;

import java.util.Date;

/**
 *
 * @author omalleym
 */
public class InPatient extends Patient
{
    private int bedNum;
    private Date admissionDate;
    
    public void operation1()
    {
        // ????
    }
    
    @Override
    public void operation2()
    {
        // ????
    }
    
}
