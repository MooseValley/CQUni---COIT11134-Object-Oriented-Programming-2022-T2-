/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01w02fixeddeposittester;

/**
 *
 * @author omalleym
 */
public class FixedDeposit 
{
    private static int accountId = 1001; // Global Data for all FixedDeposit objects to share
    
    private int accountNumber;    // individual data per FixedDeposit object
    private int periodInYears;
    private double initialAmount;


    public FixedDeposit ()
    {
        this (0, 0);
    }
    
    public FixedDeposit (int periodInYears, double initialAmount)
    {
        accountNumber = accountId;
        accountId++;

        this.periodInYears = periodInYears;
        this.initialAmount = initialAmount;
    }
    
    public int getAccountNumber()
    {
        return accountNumber;
    }
        
    public int getPeriodInYears()
    {
        return periodInYears;
    }

    public double getInitialAmount()
    {
        return initialAmount;
    }
    
    
    
    @Override
    public String toString()
    {
        return  accountNumber + 
                "   $" + String.format ("%,10.2f", initialAmount) +
                "    "  + periodInYears;
        
    }

}
