/*

Homework:
* Employees tutorial question, create an Array and anaArrayList of Employees
* Calculate the average salary for all employees
* give all employees a 10% pay rise
* Calculate the average salary for all employees
Hint: create method: getAverageSalary !!  Where do you put this method ?


 */
package w01w02fixeddeposittester;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class W01W02FixedDepositTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        FixedDeposit fd01 = new FixedDeposit (2, 2500);
        FixedDeposit fd02 = new FixedDeposit (1, 3000);
        FixedDeposit fd03 = new FixedDeposit (2, 1500);
        
        System.out.println ("Account Initial     Period");
        System.out.println ("Number  amount      in years");
        System.out.println (fd01);
        System.out.println (fd02);
        System.out.println (fd03);
        
        
        // Array of Objects
        
        FixedDeposit[] accounts = new FixedDeposit [10];
        accounts[0] = new FixedDeposit (2, 2500);
        accounts[1] = new FixedDeposit (1, 3000);
        accounts[2] = new FixedDeposit (2, 1500);
        
        for (int k = 0; k < accounts.length; k++)
        {
            if (accounts[k] != null)
                System.out.println (accounts[k]);
        }
        
        // ArrayList: dynamic array, can store any number of accounts
        // add, size, get, remove, set, clear, 
        ArrayList<FixedDeposit> accountsArrayList = new ArrayList<> ();
        accountsArrayList.add (new FixedDeposit (2, 2500) );
        accountsArrayList.add (new FixedDeposit (1, 3000) );
        accountsArrayList.add (new FixedDeposit (2, 1500) );
        
        for (int k = 0; k < accountsArrayList.size(); k++)
        {
            System.out.println (accountsArrayList.get(k) );
        }
        
        // Enhanced For Loop / For Each loop
        for (FixedDeposit fd : accountsArrayList)
        {
            System.out.println (fd);
        }
        
        
        
    }
    
}
