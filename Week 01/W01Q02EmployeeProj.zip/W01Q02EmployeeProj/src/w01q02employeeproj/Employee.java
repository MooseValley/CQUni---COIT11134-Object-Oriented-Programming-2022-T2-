/*

Data Class Recipe:

Constructor
-> Default
-> Parameterised (1, 2, 3 of these ..)
Acessor / Getters
Mutator / Setters
toString
:::

Validation:
* name cannot be blank
* name must be at least 2 characters long.  Ng
* name must start with an alphabetic letter
* salary must be > 15
* salary must be < 99

*/
package w01q02employeeproj;

/**
 *
 * @author omalleym
 */
public class Employee  // Data Class
{
    private String name;
    private double salary;
    
 
    public Employee () // Default Constructor
    {
        //name   = "";
        //salary = 0;
        this("", 0.0); // Call Parameterised Constructor
    }
    
    /*
    public Employee (String name1, double salary1) // Paremeterised Constructor #1
    {
        name = name1;
        salary = salary1;
    }
    */
    
    public Employee (String name, double salary) // Paremeterised Constructor #1
    {
        //if ((name != null) && (name.length() >= 2) && (name.charAt(0).isLetter() == true) )
            this.name = name;
        //else
        //{
            // how do you report an error to the user ???
            //System.out.println ("ERROR: ......");
            //JOptionPane.showMessageDialog (null, "Error: ....");
        //}
            
            
        this.salary = salary;
    }

    // Accessor / Getters
    
    public String getName()
    {
        return name;
    }
    
    public double getSalary()
    {
        return salary;
    }
    
    
    
    // Mutators / Setters
    
    public void setName (String name)
    {
        //if ((name != null) && (name.length() >= 2) && (name.charAt(0).isLetter() == true) )
            this.name = name;
        //else
            // how do you report an error to the user ???
    }
    
    public void setSalary (double salary)
    {
        this.salary = salary;
    }
    
    public void raiseSalary (double raisePct)
    {
        //salary = salary + salary * raisePct / 100.0;
        salary += salary * raisePct / 100.0;
    }
    
    
    

    @Override
    public String toString()
    {
        return String.format ("%-25s", name) + " $" + String.format ("%,10.2f", salary);
    }
}
