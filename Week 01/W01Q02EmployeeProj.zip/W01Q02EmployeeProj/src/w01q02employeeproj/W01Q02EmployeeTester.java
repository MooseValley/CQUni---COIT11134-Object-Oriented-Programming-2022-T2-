/*

public - ANYTHING, ANYWHERE CAN ACCESS the data / methods
private - only methods of the current class can access the data / methods
protected - only classes inside the same package can see / access the data / methods

Keep your data private
make your methods public - only if they should be

*/

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01q02employeeproj;

/**
 *
 * @author omalleym
 */
public class W01Q02EmployeeTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        Employee e01 = new Employee ();
        Employee e02 = new Employee ("Mike",        10.50);
        Employee e03 = new Employee ("Patty Cakes", 9923.99);
        
        System.out.println (e01.toString() );
        System.out.println (e02);
        System.out.println (e03);
        
        System.out.println ("Employee 3's salary is: " + e03.getSalary() );
        System.out.println ("Employee 3's name is:   " + e03.getName() );
        
        e03.setName ("Fred");
        e03.setSalary (12.15);       
        
        System.out.println ("Employee 3's salary is: " + e03.getSalary() );
        System.out.println ("Employee 3's name is:   " + e03.getName() );
        System.out.println (e03);
        
        e03.raiseSalary (15);
        System.out.println (e03);
        
    }
    
}
