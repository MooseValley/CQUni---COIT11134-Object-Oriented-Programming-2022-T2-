/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01w01rectangletester;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W01W01RectangleTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here


      Scanner input = new Scanner( System.in );      
      Rectangle rectangle = new Rectangle();
      //Printing details of default valued rectangle
      System.out.println( rectangle.toString() );
      
      //Changing length and width of the new rectangle
      System.out.println("Enter Length of the new rectangle :" );
      double tempLength = input.nextDouble();
      
        if (tempLength > 0)
          rectangle.setLength(tempLength);
      
      System.out.println("Enter Width of the new rectangle :" );
      double tempWidth = input.nextDouble();
      if (tempWidth > 0)
          rectangle.setWidth(tempWidth);
      //Printing the details of the new rectangle       
      System.out.println ( rectangle.toString() );

      
    }
    
}
