/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01w01rectangletester;

public class Rectangle
{
   private double length; // the length of the rectangle
   private double width; // the width of the rectangle

   // constructor without parameters
   public Rectangle()
   {
      this( 1.0, 1.0 );
   } // end Rectangle no-argument constructor

   // constructor with length and width supplied
   public Rectangle( double theLength, double theWidth )
   {
       // *** Mike O's NOTES ***
       // The code below is NOT Good Practice: if length is valid and width is NOT valid, we end up with an object 
       // that has only partially been created (it has a length and width is 0 or ill defined).
       // There are better ways to do this and save duplicating code.  
       // Sadly, not in scope of this course.
      setLength( theLength );
      setWidth( theWidth );
   } // end Rectangle two-argument constructor

   // validate and set length
   public void setLength( double theLength )
   {
       if ((theLength > 0) && (theLength < 20.0) )
           length = theLength;
       else
           // *** Mike O's NOTES ***
           // Not ideal - what if Web App, GUI App, ... the user will NOT see the Console screen error message !
           System.out.println ("ERROR: length must be > 0 and < 20.");
   } // end method setLength

   // validate and set width
   public void setWidth( double theWidth )
   {
       if ((theWidth > 0) && (theWidth < 20.0) )
           width = theWidth;
       else
           // *** Mike O's NOTES ***
           // Not ideal - what if Web App, GUI App, ... the user will NOT see the Console screen error message !
           System.out.println ("ERROR: width must be > 0 and < 20.");
   } // end method setWidth

   // get value of length
   public double getLength()
   {
       return length;
   } // end method getLength

   // get value of width
   public double getWidth()
   {
       return width;
   } // end method getWidth

   // calculate rectangle's perimeter
   public double getPerimeter()
   {
       return 2.0 * (length + width);
   } // end method perimeter

   // calculate rectangle's area
   public double getArea()
   {
       return length * width;
   } // end method area

   
   // convert to String
   public String toString()
   {
      return String.format( "%s: %.2f\n%s: %.2f\n%s: %.2f\n%s: %.2f",
         "Length", getLength(), "Width", getWidth(),
         "Perimeter", getPerimeter(), "Area", getArea() );
   } // end method toString
} // end class Rectangle
