/*
Use
SecureRandom
it is *much* better at generating really random number.

Random
1: 1717
2: 1680
3: 1706
4: 1640
5: 1636
6: 1621

SecureRandom
1: 1678
2: 1724
3: 1681
4: 1613
5: 1667
6: 1637

Standard Deviation, Variance


 */
package w01q03diesimulator;

import java.security.SecureRandom;
import java.util.Random;

/**
 *
 * @author omalleym
 */
public class W01Q03DieSimulator 
{
    //private static Random rand = new Random();
    private static SecureRandom rand = new SecureRandom();
    
    
    public static int getDiceRoll ()
    {
        return rand.nextInt (6) + 1;        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        int[] counts = new int [6];
        
        for (int k = 0; k < 10000; k++)
        {
            System.out.print (getDiceRoll () + ", ");
            counts [getDiceRoll () - 1]++;
        }
        System.out.println ();
        
        for (int k = 0; k < counts.length; k++)
        {
            System.out.println ((k+1) + ": " + counts[k] );
        }
        
    }
    
}
