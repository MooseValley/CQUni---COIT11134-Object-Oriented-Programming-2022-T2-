/*
 
Homework:
* Fill ibn the other Mutators / Accessor methods
* Format the output better. e.g. $1,234/00.  HINT: String.format
* See if you store accounts in an Array.  loop through array and display all accounts.
* Change over to an ArrayList to store the accounts.


*/
package w01w02bfixeddeposittester;

/**
 *
 * @author omalleym
 */
public class W01W02BFixedDepositTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        FixedDeposit acct01 = new FixedDeposit ();
        FixedDeposit acct02 = new FixedDeposit (5, 1100.00);
        
        System.out.println (acct01.toString() );
        System.out.println (acct02);
        
    }
    
}
