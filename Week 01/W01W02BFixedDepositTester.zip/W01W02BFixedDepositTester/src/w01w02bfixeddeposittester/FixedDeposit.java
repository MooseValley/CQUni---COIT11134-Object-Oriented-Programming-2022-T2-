/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01w02bfixeddeposittester;

/**
 *
 * @author omalleym
 */
public class FixedDeposit 
{
    private int accountId = 1001;

    private int accountNumber;
    private int periodInYears;
    private double initialAmount;

    public FixedDeposit () // Default Constructor
    {
        /*
        accountNumber = accountId;
        accountId++;
        
        periodInYears = 0;
        initialAmount = 0.0;
        */
        this (0, 0.0); // Call Parameterised Constructor
    }
    
    public FixedDeposit (int periodInYears, double initialAmount)  // Parameterised Constructor
    {
        accountNumber = accountId;
        accountId++;

        this.periodInYears = periodInYears;
        this.initialAmount = initialAmount;
    }
    
    // Accessors / Getters
    
    public int getAccountNumber ()
    {
        return accountNumber;
    }
    
    // Etc for others ....
    
    
    // Mutators / Setters
    
    // Do we want something outside the class to be able to change accountNumber ???
    
    public void setPeriodInYears (int periodInYears)
    {
        this.periodInYears = periodInYears;
    }
    
    // Etc for other(s) ...
    
    @Override
    public String toString()
    {
        return accountNumber + " " +
               periodInYears + " " +
               initialAmount;
    }
    
}
