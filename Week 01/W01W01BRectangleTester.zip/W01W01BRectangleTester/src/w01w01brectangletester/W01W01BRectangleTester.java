/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01w01brectangletester;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W01W01BRectangleTester {

    /**
     * @param args the command line arguments
     */
   public static void main( String[] args )
   {
      Scanner input = new Scanner( System.in );      
      Rectangle rectangle = new Rectangle();
      //Printing details of default valued rectangle
      System.out.println( rectangle.toString() );

      /*
      Mike O's NOTES:
      The code below is BAD.
      It should keep asking the user for each input until the user enters a valid value, and only then
      move onto the next input.
      The user should not be allowed to move into the next input (width) until they have entered
      a valid length.
      If any errors are encountered, meaningful error messages should be displayed.
      Also, the code below only enforces part of the validation - it does not check < 20.
      So, lots of issues.  Not good code.
      We will return and discuss this more later in this course.
      */

      //Changing length and width of the new rectangle
      System.out.println("Enter Length of the new rectangle :" );
      double tempLength = input.nextDouble();
      
        if (tempLength > 0)
          rectangle.setLength(tempLength);
      
      System.out.println("Enter Width of the new rectangle :" );
      double tempWidth = input.nextDouble();
      if (tempWidth > 0)
          rectangle.setWidth(tempWidth);
      //Printing the details of the new rectangle       
      System.out.println ( rectangle.toString() );

   }
}
