/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01w01brectangletester;

/**
 *
 * @author omalleym
 */
public class Rectangle
{
   private double length; // the length of the rectangle
   private double width; // the width of the rectangle

   // constructor without parameters
   public Rectangle()
   {
      this( 1.0, 1.0 );
   } // end Rectangle no-argument constructor

   // constructor with length and width supplied
    /*
    Mike O's NOTES: 
     Calling instance methods from a Constructor is NOT good programming practice.
     If length is valid and width is invalid, we will end up with a Rectangle object that is invalid / incomplete.

        public Rectangle( double theLength, double theWidth )
        {
           setLength( theLength );
           setWidth( theWidth );
        } // end Rectangle two-argument constructor

     The reason why the tutorial question does it is to save repeating the same validations in multiple places.
     For now, for this course, doing this is OK ... but keep in mind that there are better ways.
     e.g. call STATIC methods to validate the data values / ranges / rules before updating the instance data.
    */
   public Rectangle( double theLength, double theWidth )
   {
      setLength( theLength );
      setWidth( theWidth );
   } // end Rectangle two-argument constructor

   // validate and set length
    /*
     Mike O's NOTES: 
     Displaying error messages to the Console screen or in a Swing Dialog is NOT good enough for a real app !
     What if this class is being used in a Web App or a GUI App ???  The console screen wont be seen, so the user will never know there was an error.
     What if our program is processing / validating millions of rectangles over night ?  If we display a Swing dialog, then the whole processing job
     could be held up waiting for a user to click the "OK" button on an error dialog.
     You have to display error messages in a way that is appropriate for the application type.
     We will return and discuss this more later in this course.
    */
   public void setLength( double theLength )
   {
       if ((theLength > 0.0) && (theLength < 20.0) )
       {
           length = theLength;
       }
       else
       {
           System.out.println ("ERROR: invalid length, it must be > 0 and < 20");
       }
   } // end method setLength


   // validate and set width
   public void setWidth( double theWidth )
   {
       if ((theWidth > 0.0) && (theWidth < 20.0) )
       {
           width = theWidth;
       }
       else
       {
           System.out.println ("ERROR: invalid width, it must be > 0 and < 20");
       }
   } // end method setWidth

   // get value of length
   public double getLength()
   {
       return length;
   } // end method getLength

   // get value of width
   public double getWidth()
   {
       return width;
   } // end method getWidth

   // calculate rectangle's perimeter
   public double getPerimeter()
   {
      return 2 * (length + width);
   } // end method perimeter

   // calculate rectangle's area
   public double getArea()
   {
       return length * width;
   } // end method area
   
   
// convert to String
   public String toString()
   {
      return String.format( "%s: %.2f\n%s: %.2f\n%s: %.2f\n%s: %.2f",
         "Length", getLength(), "Width", getWidth(),
         "Perimeter", getPerimeter(), "Area", getArea() );
   } // end method toString
} // end class Rectangle

