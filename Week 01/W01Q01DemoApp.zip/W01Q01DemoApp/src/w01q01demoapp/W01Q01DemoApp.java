/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01q01demoapp;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W01Q01DemoApp 
{
    //int age;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        String name = "Mike";
        
        System.out.println ("Hello World");
        
        for (int k = 0; k < 10; k++)
        {
            System.out.print ((k+1) + " ");
        }
        System.out.println ();
        
        Scanner kb = new Scanner (System.in );
        
        System.out.println ("Enter your name: ");
        String username = "";
        username = kb.next ();
        
        System.out.println ("Enter age: ");
        int userAge = 0;
        //userAge = kb.nextInt ();
        userAge = Integer.parseInt (kb.next() );

        //String tempStr = kb.next();
        //userAge = Integer.parseInt (tempStr);

        
        kb.nextLine (); // Clear Buffer
        
        System.out.println ("Enter location: ");
        String location = "";
        location = kb.nextLine ();
        
        System.out.println ("User '" + username + "' of " + location + " is " + userAge + " years old.");

    }
    
}
