/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package w08q02employeetester;

/**
 *
 * @author omalleym
 */
public class SalariedEmployee extends Employee
{
   // Class Data:
   private double  annualSalary;

   // Default Consructor:
   public SalariedEmployee ()
   {
      this ("unknown", "unknown", "unknown", 0);
   }

   // Parameterised Consructor:
   public SalariedEmployee (String firstName, String lastName, String socialSecurityNumber, double annualSalary)
   {
      super (firstName, lastName, socialSecurityNumber);
       
      this.annualSalary = annualSalary;
   }

   // Accessors / Getters:

   public double getAnnualSalary ()
   {
      return annualSalary;
   }

   @Override
   public double getPaymentAmount ()
   {
      return annualSalary;
   }

   

   // Mutators / Setters:

   public void setAnnualSalary (double annualSalary)
   {
      this.annualSalary = annualSalary;
   }

   @Override
   public String toString ()
   {
      return 
         annualSalary + "\t" + 
         "";
   }

   public String toStringWithLabels ()
   {
      return 
         super.toString()   + "\t" +
         "AnnualSalary: "   + annualSalary + "\n" + 
         "";
   }

} // SalariedEmployee
