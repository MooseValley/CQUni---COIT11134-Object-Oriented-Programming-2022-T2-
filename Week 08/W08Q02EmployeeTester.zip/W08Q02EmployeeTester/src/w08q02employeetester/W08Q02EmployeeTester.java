/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w08q02employeetester;

/**
 *
 * @author omalleym
 */
public class W08Q02EmployeeTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        SalariedEmployee emp01 = new SalariedEmployee ("Mike", "0", "332-22-1234", 200.0);
        System.out.println ("\n" + "SalariedEmployee:");
        System.out.println (emp01.toString() );
        System.out.println (emp01.getPaymentAmount() );
        
        System.out.println ("\n");
        Invoice inv01 = new Invoice ("CPU2331", "Intel i7 CPU", 4, 399.99);
        System.out.println (inv01.toString() );
        System.out.println (inv01.getPaymentAmount() );
        

        System.out.println ("\n" + "Payable Objects Array:");

        // create six-element Payable array
        Payable[] payableObjects = new Payable[ 3 ];

        // populate array with objects that implement Payable
        payableObjects[ 0 ] = new Invoice( "01234", "seat", 2, 375.00 );
        payableObjects[ 1 ] = new Invoice( "56789", "tire", 4, 79.95 );
        payableObjects[ 2 ] = new SalariedEmployee( "John", "Smith", "111-11-1111", 60000.00 );

        System.out.println("Invoices and Employees processed polymorphically:\n" ); 

        // generically process each element in array payableObjects
        double totalPayable = 0;
        
        for ( Payable currentPayable : payableObjects )
        {
           
           // output currentPayable and its appropriate payment amount
           System.out.println(currentPayable.getClass().getTypeName() ); 
           System.out.printf( "%s \n", currentPayable.toString() ); 

           System.out.printf( "%s: $%,.2f\n\n",
              "payment due", currentPayable.getPaymentAmount() ); 
           
           if (currentPayable instanceof Invoice)
                totalPayable += currentPayable.getPaymentAmount();
        }
        System.out.printf( "%s: $%,.2f \n", "Total Payable", totalPayable);
    }
    
}
