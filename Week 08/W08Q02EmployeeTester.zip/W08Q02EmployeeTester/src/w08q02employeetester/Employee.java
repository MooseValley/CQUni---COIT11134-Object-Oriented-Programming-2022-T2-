/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package w08q02employeetester;

/**
 *
 * @author omalleym
 */
public abstract class Employee implements Payable
{
   private String firstName;
   private String lastName;
   private String socialSecurityNumber;
   
   // missing block of codes to be completed for completing contract with interface Payable
   
   public Employee()
   {
       this ("unknown", "unknown", "unknown");
   }
   
   public Employee(String firstName, String lastName, String socialSecurityNumber)
   {
       this.firstName            = firstName;
       this.lastName             = lastName;
       this.socialSecurityNumber = socialSecurityNumber;
   }


   // Accessors / Getters:

   public String getFirstName ()
   {
      return firstName;
   }

   public String getLastName ()
   {
      return lastName;
   }

   public String getSocialSecurityNumber ()
   {
      return socialSecurityNumber;
   }

   // Mutators / Setters:

   public void setFirstName (String firstName)
   {
      this.firstName = firstName;
   }

   public void setLastName (String lastName)
   {
      this.lastName = lastName;
   }

   public void setSocialSecurityNumber (String socialSecurityNumber)
   {
      this.socialSecurityNumber = socialSecurityNumber;
   }

   @Override
   public String toString ()
   {
      return 
         firstName            + "\t" + 
         lastName             + "\t" + 
         socialSecurityNumber + "\t" + 
         "";
   }
 
}
