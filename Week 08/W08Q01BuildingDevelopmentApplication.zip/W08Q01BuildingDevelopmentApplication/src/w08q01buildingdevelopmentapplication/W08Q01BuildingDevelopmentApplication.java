/*
Q1. A proposed building application has to be verified that it is meeting the side, front and rear 
clearance requirements of the proposed building within the plot specified. 

Minimum required width clearance for a building approval is 2m (1m on each side of the building 
within the plot). It can be calculated by the following formula:
    width clearance = plot width – building width

Similar requirement is applied on length side to find out front and rear clearance of 2m 
(1m front and 1m rear).

Complete the missing block of codes to produce one approved and one rejected 
BuildingDevelopmentApplication.  


public class BuildingDevelopmentApplication {
    
    // create instance fields to store the values of plot width and length
    // create instance fields to store the values of building width and length
   // create instance fields to store the date of application	
        
    boolean approved = false;
    
// create parameterized constructor here for BuildingDevelopmentApplication


    // inner class to verify the building plan adheres to front, rear and sides clearance 
    class Verification{
        boolean valid ;
        private static final double MINIMUM_REQUIRED = 2;

        public Verification() {
            valid = false;
        }
        
        //to verify the building plan adhers to front, rear and sides clearance 
        boolean check(){
            if(checkWidth() && checkLength())
           {
	// valid value has to be true only when check width and check length are true

            }
            return valid;
            
        }

       // to find out the required width clearance
       boolean checkWidth(){
            // complete the missing block of codes by checking required clearance
        }
        
       // to find out the required length clearance
       boolean checkLength(){
            // complete the missing block of codes by checking required clearance
        }
        
    }
    
    // to display the plan is building plan is approved or not
    public void displayApproval(){
        Verification test = new Verification();
        approved = test.check();
        if(approved)
            System.out.println("Building plan Approved");
        else
            System.out.println("Building plan Rejected");
    }
    
    public static void main(String [] args){
       
        // complete the missing block of codes to create BuildingDevelopmentApplication objects 
        // and invoke appropriate methods to print whether it is approved or rejected
       
    }
}

*/
package w08q01buildingdevelopmentapplication;

/**
 *
 * @author omalleym
 */
public class W08Q01BuildingDevelopmentApplication 
{

    // create instance fields to store the values of plot width and length
    // create instance fields to store the values of building width and length
    // create instance fields to store the date of application	
    private double plotWidth;
    private double plotLength;
    private double buildingWidth;
    private double buildingLength;
    private String dateOfApplication;
    
    private boolean approved = false;
    
    // create parameterized constructor here for BuildingDevelopmentApplication
    
    public W08Q01BuildingDevelopmentApplication ()
    {
        this (0, 0, 0, 0, "unknown");
    }
    
    public W08Q01BuildingDevelopmentApplication (double plotWidth, double plotLength, double buildingWidth, double buildingLength, String dateOfApplication)
    {
        this.plotWidth         = plotWidth;
        this.plotLength        = plotLength;
        this.buildingWidth     = buildingWidth;
        this.buildingLength    = buildingLength;
        this.dateOfApplication = dateOfApplication;
    }
    

    // inner class to verify the building plan adheres to front, rear and sides clearance 
    class Verification
    {
        boolean valid ;
        private static final double MINIMUM_REQUIRED = 2;

        public Verification() 
        {
            valid = false;
        }
        
        //to verify the building plan adhers to front, rear and sides clearance 
        boolean check()
        {
            if(checkWidth() && checkLength())
            {
                // valid value has to be true only when check width and check length are true
                valid = true;
            }
            return valid;
            
        }

       // to find out the required width clearance
       boolean checkWidth()
       {
           // complete the missing block of codes by checking required clearance
           boolean widthCheck = false;

           if (plotWidth - buildingWidth >= MINIMUM_REQUIRED)
           {
               widthCheck = true;
           }
           
           return widthCheck;
        }
        
       // to find out the required length clearance
       boolean checkLength()
       {
            // complete the missing block of codes by checking required clearance
           /*
           boolean lengthCheck = false;

           if (plotLength - buildingLength >= MINIMUM_REQUIRED)
           {
               lengthCheck = true;
           }
           
           return lengthCheck;
           */
           
           return (plotLength - buildingLength >= MINIMUM_REQUIRED);
        }
        
    }
    
    // to display the plan is building plan is approved or not
    public void displayApproval(){
        Verification test = new Verification();
        approved = test.check();
        if(approved)
            System.out.println("Building plan Approved");
        else
            System.out.println("Building plan Rejected");
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        /*
        complete the missing block of codes to create BuildingDevelopmentApplication objects and 
        invoke appropriate methods to print whether it is approved or rejected
       */
        
       W08Q01BuildingDevelopmentApplication app1 = new W08Q01BuildingDevelopmentApplication (20.0, 25.0, 18.1, 19.2, "5-Sep-2022");
       app1.displayApproval();

       W08Q01BuildingDevelopmentApplication app2 = new W08Q01BuildingDevelopmentApplication (20.0, 25.0, 17.9, 19.2, "5-Sep-2022");
       app2.displayApproval();
    }
    
}
