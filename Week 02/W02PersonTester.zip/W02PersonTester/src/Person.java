/*
 Author: Mike O'Malley
 Source: Person.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 18-July-2022 Mike O    Created.

*/
public class Person
{

   // Class Data:
   private String  name;
   private int     yearOfBirth;

   // Default Consructor:
   public Person ()
   {
      this ("unknown", 1990);
   }

   // Parameterised Consructor:
   public Person (String name, int yearOfBirth)
   {
      this.name        = name;
      this.yearOfBirth = yearOfBirth;
   }

   // Accessors / Getters:

   public String getName ()
   {
      return name;
   }

   public int getYearOfBirth ()
   {
      return yearOfBirth;
   }

   // Mutators / Setters:

   public void setName (String name)
   {
      this.name = name;
   }

   public void setYearOfBirth (int yearOfBirth)
   {
      this.yearOfBirth = yearOfBirth;
   }

   @Override
   public String toString ()
   {
      return 
         String.format ("%-10s", this.getClass().getName()) + " " +
         String.format ("%-25s", name)                      + " " +          
         String.format ("%8d", yearOfBirth)                 + " " + 
         "";
   }

} // Person
