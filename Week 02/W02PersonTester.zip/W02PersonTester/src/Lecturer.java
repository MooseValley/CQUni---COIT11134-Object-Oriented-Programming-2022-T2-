/*
 Author: Mike O'Malley
 Source: Lecturer.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 18-July-2022 Mike O    Created.

*/
public class Lecturer extends Person
{

   // Class Data:
   private double  salary;

   // Default Consructor:
   public Lecturer ()
   {
      this ("unknown", 1900, 10.0);
   }

   // Parameterised Consructor:
   public Lecturer (String name, int yearOfBirth, double salary)
   {
      super (name, yearOfBirth);    
      System.out.println ("Lecturer(): " + name + " : " + yearOfBirth);
      
      this.salary = salary;
   }

   // Accessors / Getters:

   public double getSalary ()
   {
      return salary;
   }

   // Mutators / Setters:

   public void setSalary (double salary)
   {
      this.salary = salary;
   }

   @Override
   public String toString ()
   {
      return 
         super.toString() + "\t" +
         salary           + "\t" + 
         "";
   }

} // Lecturer
