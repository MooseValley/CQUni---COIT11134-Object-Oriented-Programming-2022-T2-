
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author omalleym
 */
public class W02PersonTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        ArrayList<Person> people = new ArrayList<>();
        
        people.add (new Person   ("Mike",    1980) );
        people.add (new Lecturer ("Frankie", 2018, 19.99) );
        people.add (new Student  ("Bella",   2019, "Bird Science") );
        
        for (Person p : people)
        {
            System.out.println (p);
        }
        
    }
    
}
