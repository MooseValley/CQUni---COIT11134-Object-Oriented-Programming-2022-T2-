/*
 Author: Mike O'Malley
 Source: Student.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 18-July-2022 Mike O    Created.

*/
public class Student extends Person
{

   // Class Data:
   private String  major;

   // Default Consructor:
   public Student ()
   {
      this ("unknown", 1990, "TBC");
   }

   // Parameterised Consructor:
   public Student (String name, int yearOfBirth, String major)
   {
       super (name, yearOfBirth);
       
       this.major = major;
   }

   // Accessors / Getters:

   public String getMajor ()
   {
      return major;
   }

   // Mutators / Setters:

   public void setMajor (String major)
   {
      this.major = major;
   }

   @Override
   public String toString ()
   {
      return 
         super.toString() + "\t" +
         "                 " +
         major           + "\t" + 
         "";
   }

} // Student
