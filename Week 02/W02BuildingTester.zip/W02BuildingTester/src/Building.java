/*
 Author: Mike O'Malley
 Source: Building.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 18-July-2022 Mike O    Created.

*/
public class Building
{
   // Class Data:
   private String  address;
   private double  buildingArea; // sqm

   // Default Consructor:
   public Building ()
   {
      this ("", 0.0);
   }

   // Parameterised Consructor:
   public Building (String address, double buildingArea)
   {
      this.address      = address;
      this.buildingArea = buildingArea;
   }

   // Accessors / Getters:

   public String getAddress ()
   {
      return address;
   }

   public double getBuildingArea ()
   {
      return buildingArea;
   }

   // Mutators / Setters:

   public void setAddress (String address)
   {
      this.address = address;
   }

   public void setBuildingArea (double buildingArea)
   {
      this.buildingArea = buildingArea;
   }

   @Override
   public String toString ()
   {
      return 
         String.format ("%-30s", address)       + " " + 
         String.format ("%10.1f", buildingArea) + " " + 
         "";
   }

    public static void printHeadings()
    {
        System.out.println ("Id Address                Building Area (sqm)   Bed  Bath Garages");
        System.out.println ("-- ---------------------- ------------------- ----- ----- -------");
    }
} // Building
