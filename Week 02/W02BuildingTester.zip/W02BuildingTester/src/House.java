/*
 Author: Mike O'Malley
 Source: House.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 18-July-2022 Mike O    Created.

*/
public class House extends Building
{
   // Class Data:
   private int     numBedrooms;
   private int     numBathrooms;
   private int     garages; // Number of parking spaces in a locable, undercover area.

   // Default Consructor:
   public House ()
   {
       this ("", 0.0, 0, 0, 0);
   }

   // Parameterised Consructor:
   public House (String address, double buildingArea, int numBedrooms, int numBathrooms, int garages)
   {
      super (address, buildingArea);

      this.numBedrooms  = numBedrooms;
      this.numBathrooms = numBathrooms;
      this.garages      = garages;
   }

   // Accessors / Getters:

   public int getNumBedrooms ()
   {
      return numBedrooms;
   }

   public int getNumBathrooms ()
   {
      return numBathrooms;
   }

   public int getGarages ()
   {
      return garages;
   }

   // Mutators / Setters:

   public void setNumBedrooms (int numBedrooms)
   {
      this.numBedrooms = numBedrooms;
   }

   public void setNumBathrooms (int numBathrooms)
   {
      this.numBathrooms = numBathrooms;
   }

   public void setGarages (int garages)
   {
      this.garages = garages;
   }

   @Override
   public String toString ()
   {
      return 
         super.toString()                   + " " + 
         String.format("%5d", numBedrooms)  + " " + 
         String.format("%5d", numBathrooms) + " " + 
         String.format("%5d", garages)      + " " + 
         "";
   }

} // House
