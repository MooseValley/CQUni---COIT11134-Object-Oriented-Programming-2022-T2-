/*
 Author: Mike O'Malley
 Source: BuildingTester.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 18-July-2022 Mike O    Created.

*/
public class BuildingTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        Building[] buildings = new Building [10];
        
        
        buildings [0] = new Building ();
        buildings [1] = new Building ("123 Rocky Rd", 203.5);
        
        buildings [2] = new House ();
        buildings [3] = new House ("445 Gladstone St", 1299, 4, 2, 2);
        buildings [4] = new House ("446 Gladstone St", 220,  3, 1, 0);

        
        Building.printHeadings();
        int count = 0;

        /*
        for (int k = 0; k < buildings.length; k++)
        {
            if (buildings [k] != null)
            {
                System.out.println ( (k+1) + ". " + buildings [k]);
                count++;
            }
        }
        */

        for (Building b : buildings) // Enhanced For Loop:
        {
            if (b != null)
            {
                count++;
                System.out.println (count + ". " + b);
            }
        }
        
        System.out.println ("\n" + count + " buildings / houses found.");
        
        
        // Display the Total Area for all Buildings
        // Display the Average Area for all Buildings
        
        double totalArea = 0.0;
        int count2 = 0;
        for (Building b : buildings)
        {
            if (b != null)
            {
               count2++;
               totalArea += b.getBuildingArea ();
            }
        }
        double averageArea = 0.0;
        if (count2 > 0)
            averageArea = totalArea / count2;
                
        System.out.println ("Total Area =   " + String.format ("%.2f", totalArea)   );
        System.out.println ("Average Area = " + String.format ("%.2f", averageArea) );
        
        // Display the Total number of bedrooms for all Houses
        // Display the Average Number of bedrooms per House 
        // Display the Average Number of bedrooms per Building
        // HINT: instanceof

        int totalBedroomsHouses = 0;
        int totalBedroomsAllBuildings = 0;
        int countHouses = 0;
        int countBuildings = 0;  // Num Buildings in array that are NOT houses
        
        for (Building b : buildings)
        {
            if (b != null)
            {
                if (b instanceof House)
                {
                    countHouses++;
                    totalBedroomsHouses += ((House) b).getNumBedrooms (); // Tyecast to keep java happy.
                }
                else if (b instanceof Building)
                {
                    countBuildings++;
                }
            }
        }
        double averageBedroomsHouses       = 0.0;
        double averageBedroomsAllBuildings = 0.0; // Includes houses

        if (countHouses > 0)
            averageBedroomsHouses = 1.0 * totalBedroomsHouses / countHouses; // WARNING: integer division => 1.0 * ...
        if (countBuildings + countHouses > 0)
            averageBedroomsAllBuildings = 1.0 * (totalBedroomsHouses + totalBedroomsAllBuildings) / (countBuildings + countHouses);
                
        System.out.println ("Total Bedrooms for Houses          = " + String.format ("%d", totalBedroomsHouses)   );
        System.out.println ("Total Bedrooms for ALL Buildings   = " + String.format ("%d", totalBedroomsHouses + totalBedroomsAllBuildings)   );
        System.out.println ("Average Bedrooms for Houses        = " + String.format ("%.2f", averageBedroomsHouses) );       
        System.out.println ("Average Bedrooms for ALL Buildings = " + String.format ("%.2f", averageBedroomsAllBuildings) );       
 
    }
    
}
