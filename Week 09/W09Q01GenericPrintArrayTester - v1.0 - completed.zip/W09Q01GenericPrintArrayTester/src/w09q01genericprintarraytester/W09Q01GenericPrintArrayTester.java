/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w09q01genericprintarraytester;


/**
 *
 * @author omalleym
 */
public class W09Q01GenericPrintArrayTester 
{
    /*
    public static void printArray (Integer[] arr)
    {
        for (Integer k : arr)
            System.out.print (k + ", ");
        System.out.println ();
    }
    
    public static void printArray (String[] arr)
    {
        for (String k : arr)
            System.out.print (k + ", ");
        System.out.println ();
    }
    */

    
    public static <T> void printArray (T[] arr) throws InvalidSubscriptException
    {
        /*
        for (T k : arr)
            System.out.print (k + ", ");
        System.out.println ("\n-> " + arr.length + " items listed.");
        */
        printArray (arr, "items", 0, arr.length - 1);
    }
    

    public static <T> void printArray (T[] arr, String dataNameStr) throws InvalidSubscriptException
    {
        /*
        for (T k : arr)
            System.out.print (k + ", ");
        System.out.println ("\n-> " + arr.length + " " + dataNameStr + " listed.");
        */
        printArray (arr, dataNameStr, 0, arr.length - 1);
    }

    public static <T> void printArray (T[] arr, int fromIndex, int toIndex) throws InvalidSubscriptException
    {
        printArray (arr, "items", fromIndex, toIndex);
    }

    public static <T> void printArray (T[] arr, String dataNameStr, int fromIndex, int toIndex) throws InvalidSubscriptException //ayIndexOutOfBoundsException
    {
        if ((fromIndex < 0) || (fromIndex > arr.length - 1) ||
            (toIndex   < 0) || (toIndex   > arr.length - 1) )
        {
            //throw new ArrayIndexOutOfBoundsException ("ERROR: indexes " + fromIndex + " and " + toIndex +
            //                                          " should be between 0 and " + arr.length + ".");
            throw new InvalidSubscriptException ("ERROR: indexes " + fromIndex + " and " + toIndex +
                                                      " should be between 0 and " + arr.length + ".");
        }
        else if (fromIndex > toIndex) 
        {
            //throw new ArrayIndexOutOfBoundsException ("ERROR: " + fromIndex + " should be <= " + toIndex + ".");
            throw new InvalidSubscriptException ("ERROR: " + fromIndex + " should be <= " + toIndex + ".");
        }
            
        int count = 0;
        for (int k = fromIndex; k <= toIndex; k++)
        {
            System.out.print (arr[k] + ", ");
            count++;
        }

        System.out.println ("\n-> " + count + " " + dataNameStr + " listed.");
    }

    public static void main(String[] args) 
    {
        Integer[] ints    = {10, 30, 45, 77, 33, 5};
        String[]  strings = {"Mike", "Frankie", "Bella", "Patty", "Teenie", "Sam", "Hank", "Ben"};
        
        try
        {
            printArray (strings);
            printArray (ints,    "ages");
            printArray (strings, "names");
            printArray (strings, 1, 3);
            printArray (strings, "names", 1, 3);
            printArray (strings, "names", -1, 3);
            printArray (strings, "names", 1, 99);
            printArray (strings, "names", 99, 1);
        }
        catch (InvalidSubscriptException err)
        {
            err.printStackTrace();
        }
    }
    
}
