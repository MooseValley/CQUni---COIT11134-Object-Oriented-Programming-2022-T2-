/*
Number
    Double
    Integer
    Long
    Byte
    Character
    :::::
 */
package w10q01generictourtest;

/**
 *
 * @author omalleym
 */
public class Tour <T extends Number,U,V> 
{
    U name; 
    V activity;
    T price;

    public Tour(U name, V activity, T price) {
        this.name = name;
        this.activity = activity;
        this.price = price;
    }

    public U getName() {
        return name;
    }

    public void setName(U name) {
        this.name = name;
    }

    public V getActivity() {
        return activity;
    }

    public void setActivity(V activity) {
        this.activity = activity;
    }

    public T getPrice() {
        return price;
    }

    public void setPrice(T price) {
        this.price = price;
    }

    
    @Override
    public String toString()  {
        return "Name : "  +  name +  "\nActivity : "+ activity +"\nPrice : $" +  price +   '\n';
    }

}// end of class Tour

