/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w10q01generictourtest;

/**
 *
 * @author omalleym
 */
import java.util.Date;


public class W10Q01GenericTourTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        /*
        Tour tour1  =  new Tour("Sydney","Opera house visit", 250);
        Tour tour2  =  new Tour("National Parks", "Trekking", 125);

        System.out.println( tour1); 
        System.out.println( tour2);
        */

        Tour tour1  =  new Tour("Sydney","Opera house visit", 250);
        Tour tour2  =  new Tour("National Parks", "Trekking", 125.5);

        System.out.println( tour1); 
        System.out.println( tour2);

        //Tour tour3  =  new Tour(new Employee ("Mike"), new Date(), "Hello World");
        //System.out.println( tour3);
        
        Tour tour4  =  new Tour(new Employee ("Mike"), new Date(), 123.99);
        System.out.println( tour4);

    }
    
}
