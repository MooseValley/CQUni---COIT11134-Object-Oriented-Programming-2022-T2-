

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package w10q02needabletester;

import java.util.ArrayList;


/**
 *
 * @author SIERP1
 */
public class AllExpense<T extends Needable> {
    private ArrayList<T> allList;//

    public AllExpense() {

    }

    public AllExpense(ArrayList<T> aList) {
        this.allList = aList;
    }

    /**
     *
     * @return total of all tour expenses
     */
    public double findTotal(){
        double total = 0;
        for(T x: allList)
            total = x.getCost() + total;
        return total;

    }
    public static void main( String [] args)
    {


    }
}
