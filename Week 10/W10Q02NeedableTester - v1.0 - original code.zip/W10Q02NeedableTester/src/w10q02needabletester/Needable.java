/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package w10q02needabletester;

/**
 *
 * @author Venu
 * @param <T>
 */
public interface Needable {
    public double getCost() ;

}
