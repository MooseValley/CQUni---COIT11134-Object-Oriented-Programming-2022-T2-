

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package w10q02needabletester;

import java.util.ArrayList;


/**
 *
 * @author SIERP1
 */
public class AllExpense <T extends Needable> 
{
    private ArrayList<T> allList;//

    public AllExpense() {
        allList = new ArrayList<>();
    }
    
    public void add (T item)
    {
        allList.add (item);
    }

    /**
     *
     * @return total of all tour expenses
     */
    public double findTotal ()
    {
        /*
        double total = 0;
        for(T x: allList)
            total = x.getCost() + total;
        return total;
        */
        return findTotal ("");
    }

    public double findTotal (String targetClassStr)
    {
        double total = 0;
        for(T x : allList)
        {
            if ((targetClassStr.equals ("") == true) ||
                (x.getClass().getName().endsWith ("." + targetClassStr) == true) )
                total = x.getCost() + total;
        }

        return total;
    }
    
    
    public double findTotal (Class targetClass)
    {
        double total = 0;
        for(T x : allList)
        {
            if (x.getClass() == targetClass )
            //if (targetClass.isInstance (x) )  // Also works fine
                total = x.getCost() + total;
        }

        return total;
    }


    public double findLowest (String targetClassStr)
    {
        double lowest = Double.MAX_VALUE;
        
        for(T x : allList)
        {
            if ((targetClassStr.equals ("") == true) ||
                (x.getClass().getName().endsWith ("." + targetClassStr) == true) )
                if (lowest > x.getCost() )
                    lowest = x.getCost();
        }

        return lowest;
    }

    public double findHighest (String targetClassStr)
    {
        double highest = -1 * Double.MAX_VALUE;
        
        for(T x : allList)
        {
            if ((targetClassStr.equals ("") == true) ||
                (x.getClass().getName().endsWith ("." + targetClassStr) == true) )
                if (highest < x.getCost() )
                    highest = x.getCost();
        }

        return highest;
    }

    public double findLowest (Class targetClass)
    {
        double lowest = Double.MAX_VALUE;

        for(T x : allList)
        {
            //if (x.getClass() == targetClass )
            if (targetClass.isInstance (x) )  // Also works fine
                if (lowest > x.getCost() )
                    lowest = x.getCost();
        }

        return lowest;
    }
    
    public double findHighest (Class targetClass)
    {
        double highest = -1.0 * Double.MAX_VALUE;
        
        /*if ((allList != null) && (allList.size() > 0) )
        {
            highest = allList.get(0).getCost();
        */

        for(T x : allList)
        {
            //if (x.getClass() == targetClass )
            if (targetClass.isInstance (x) )  // Also works fine
                if (highest < x.getCost() )
                    highest = x.getCost();
        }

        return highest;
    }

}
