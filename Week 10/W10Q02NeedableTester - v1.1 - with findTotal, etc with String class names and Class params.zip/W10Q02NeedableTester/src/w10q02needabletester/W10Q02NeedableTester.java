/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w10q02needabletester;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class W10Q02NeedableTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // Tour
        Tour tour1  =  new Tour("Sydney",         250);
        Tour tour2  =  new Tour("National Parks", 110.75);

        AllExpense<Tour> te = new AllExpense<>();
        te.add (tour1);
        te.add (tour2);
        
        System.out.println( "Total of Tour Expenses : $" + te.findTotal());


        // Study
        Study study1  =  new Study("COIT29222", "Programming", 2500);
        Study study2  =  new Study("COIT20247", "Database",    2300.50);

        AllExpense<Study> se = new AllExpense<>();
        se.add(study1);
        se.add(study2);
        
        System.out.println( "Total of Study Expenses : $"+se.findTotal());

        System.out.println( "Total of Study and tour Expenses : $"+(se.findTotal() + te.findTotal()) );
         
        
/*  
        Week 2
        Vehicles[] v = ....
        Car
        Trucks
        instanceof
*/

        /*
        Create a single AllExpense object
        add all tours and study to it
        call findTotal
        see if you can find the total just if Study objects (might need an extra instance method)
        */

        
        System.out.println("\n" + "All in One:");
        AllExpense<Needable> allExpenses = new AllExpense<>();
        allExpenses.add (tour1);
        allExpenses.add (tour2);
        allExpenses.add (study1);
        allExpenses.add (study2);
        
        //System.out.println("Study Class name: " + study2.getClass().getName() ); 

        System.out.println("Total of Study and Tour Expenses : $" + allExpenses.findTotal () );
        System.out.println("Total of Study Expenses :          $" + allExpenses.findTotal ("Study") );
        System.out.println("Total of Study Expenses :          $" + allExpenses.findTotal (Study.class) );
        System.out.println("Total of Study and Tour Expenses : $" + allExpenses.findTotal (Needable.class) );

        System.out.println("\n" + "MIN / MAX: String methods");
        System.out.println("Study and Tour Expenses MIN:       $" + allExpenses.findLowest  ("") );
        System.out.println("Study and Tour Expenses MAX:       $" + allExpenses.findHighest ("") );
        System.out.println("Study Expenses MIN:                $" + allExpenses.findLowest  ("Study") );
        System.out.println("Study Expenses MAX:                $" + allExpenses.findHighest ("Study") );
        
        System.out.println("\n" + "MIN / MAX: Class methods");
        System.out.println("Study and Tour Expenses MIN:       $" + allExpenses.findLowest  (Needable.class) );
        System.out.println("Study and Tour Expenses MAX:       $" + allExpenses.findHighest (Needable.class) );
        System.out.println("Study Expenses MIN:                $" + allExpenses.findLowest  (Study.class) );
        System.out.println("Study Expenses MAX:                $" + allExpenses.findHighest (Study.class) );

    }
    
}
