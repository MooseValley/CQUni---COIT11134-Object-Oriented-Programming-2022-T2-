/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w04q03calculator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private Button d7Button;
    @FXML
    private Button d8Button;
    @FXML
    private Button d9Button;
    @FXML
    private Button addButton;
    @FXML
    private Button d4Button;
    @FXML
    private Button d5Button;
    @FXML
    private Button d6Button;
    @FXML
    private Button subtractButton;
    @FXML
    private Button d1Button;
    @FXML
    private Button d2Button;
    @FXML
    private Button d3Button;
    @FXML
    private Button divideButton;
    @FXML
    private Button d0Button;
    @FXML
    private Button d00Button;
    @FXML
    private Button fullStopButton;
    @FXML
    private Button multiplyButton;
    @FXML
    private TextField displayTextField;
    @FXML
    private Button clearButton;
    @FXML
    private Button equalsButton;
    
    private double currentValue;
    private String currentOperation;
    
    
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void d7ButtonHandler(ActionEvent event) 
    {
       displayTextField.setText(displayTextField.getText() + "7");
    }

    @FXML
    private void d8ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "8");
    }

    @FXML
    private void d9ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "9");
    }

    @FXML
    private void addButtonHandler(ActionEvent event) {
        currentValue = Double.parseDouble (displayTextField.getText() );
        currentOperation = "+";
        displayTextField.setText ("0");
    }

    @FXML
    private void d4ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "4");
    }

    @FXML
    private void d5ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "5");
    }

    @FXML
    private void d6ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "6");
    }

    @FXML
    private void subtractButtonHandler(ActionEvent event) {
    }

    @FXML
    private void d1ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "1");
    }

    @FXML
    private void d2ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "2");
    }

    @FXML
    private void d3ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "3");
    }

    @FXML
    private void divideButtonHandler(ActionEvent event) {
    }

    @FXML
    private void d0ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "0");
    }

    @FXML
    private void d00ButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + "00");
    }

    @FXML
    private void fullStopButtonHandler(ActionEvent event) {
        displayTextField.setText(displayTextField.getText() + ".");
    }

    @FXML
    private void multiplyButtonHandler(ActionEvent event) {
    }

    @FXML
    private void clearButtonHandler(ActionEvent event) {
        displayTextField.setText("0");
    }

    @FXML
    private void equalsButtonHandler(ActionEvent event) {
        if (currentOperation.equals ("+") == true)
        {
            double nextValue = Double.parseDouble (displayTextField.getText() );
            double result = nextValue + currentValue;
            displayTextField.setText ("" + result);
        }
            
    }
    
}
