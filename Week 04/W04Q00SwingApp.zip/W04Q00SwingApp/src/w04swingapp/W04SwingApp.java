/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w04swingapp;

import java.awt.FlowLayout;
import javax.swing.*;

/**
 *
 * @author omalleym
 */
public class W04SwingApp extends JFrame
{
    private JLabel     nameLabel     = new JLabel ("Enter name:");
    private JTextField nameTextField = new JTextField (20);
    
    private JButton    sayHelloButton = new JButton ("Hello");
    
    
    
    public W04SwingApp()
    {
        setLayout (new FlowLayout () );
        
        add (nameLabel);
        add (nameTextField);
        add (sayHelloButton);
        
        sayHelloButton.addActionListener (event -> sayHello () );
    }
    
    private void sayHello ()
    {
        JOptionPane.showMessageDialog (null, "Hello " + nameTextField.getText() );
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        W04SwingApp app = new W04SwingApp ();
        app.setSize (500, 500);
        app.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        app.setVisible (true);
        
    }
    
}
