/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w04q01studentloggernb8;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField studentIdTextField;
    @FXML
    private Button clearButton;
    @FXML
    private Button addButton;
    @FXML
    private TextArea outputTextArea;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    

    @FXML
    private void clearButtonHandler(ActionEvent event) 
    {
        outputTextArea.setText ("");
    }

    @FXML
    private void addButtonHandler(ActionEvent event) 
    {
        String nameStr   = nameTextField.getText();
        String studIdStr = studentIdTextField.getText();
        
        // Validation here ....
        
        
        outputTextArea.setText (studIdStr + " " + nameStr + "\n" +
                                outputTextArea.getText () );

        //outputTextArea.setText (outputTextArea.getText () + "\n" +
        //                        studIdStr + " " + nameStr);
        
        // Clear Inputs
        nameTextField.setText ("");
        studentIdTextField.setText ("");     
    }
}
