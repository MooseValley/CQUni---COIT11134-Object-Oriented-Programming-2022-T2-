/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w04q02profitlosnb8v2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField purchaseCostTextField;
    @FXML
    private TextField salePriceTextField;
    @FXML
    private Button calcProfitLossButon;
    @FXML
    private Label outputLabel;
    @FXML
    private Button exitButton;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void calcProfitLossButonHandler(ActionEvent event) 
    {
        double purchaseCost = Double.parseDouble (purchaseCostTextField.getText() );
        double salePrice    = Double.parseDouble (salePriceTextField.getText() );
        
        double profitLossPct = (salePrice - purchaseCost) / purchaseCost * 100.0;

        outputLabel.setText ("Profit/Loss is " + String.format ("%.1f", profitLossPct) + "%");
    }

    @FXML
    private void exitButtonHandler(ActionEvent event) 
    {
        Alert alert = new Alert (Alert.AlertType.CONFIRMATION, "Are you sure you want to Exit?");

        alert.showAndWait().ifPresent ( response -> 
            {
               if (response == ButtonType.OK) 
               {
                   Platform.exit();
               }
            });        
    }
    
}
