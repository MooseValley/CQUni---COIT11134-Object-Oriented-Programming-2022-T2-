/*
Mike O's Extras / Homework:
* Create a class called BankInterest and create an object of this type when the Calculate button is clicked.
* Add the BankInterest object to an ArrayList of BankInterest objects.
* Use the ArrayList to display the data in the textarea
* Also display the number of BankInterest objects and the average interest calculated so far.
* Auto allocate a unique Acct Id (hint: static).

 */
package w07q01bankinteresttester;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable 
{
    public static final double MIN_PRINCIPAL   = 10;
    public static final double MAX_PRINCIPAL   = 1_000_000;

        
    private Label label;
    @FXML
    private TextField principalTextField;
    @FXML
    private TextField interestRateTextField;
    @FXML
    private Button calculateButton;
    @FXML
    private TextField yearsTextField;
    @FXML
    private TextArea outputTextArea;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    private double strToDouble (TextField inputTextField, double minValue, double maxValue, String dataType)
    {
        double value = 0.0;
        
        try
        {
            String inputStr = inputTextField.getText();
            inputStr = inputStr.replace (",", "");
            inputStr = inputStr.replace ("$", "");
            inputStr = inputStr.replace ("%", "");
            inputStr = inputStr.trim();

            value    = Double.parseDouble (inputStr);

            if ((value < minValue) || (value > maxValue) )
                throw new NumberFormatException ();
        }
        catch (NumberFormatException err)
        {
            JOptionPane.showMessageDialog (null, "ERROR: invalid " + dataType + ": must be " + minValue + " to " + maxValue + ".");
            inputTextField.requestFocus();
            value = minValue - 1;
        }
        
        return value;
    }

    @FXML
    private void calculateButtonHandler(ActionEvent event) 
    {
        double principal    = 0.0;
        double interestRate = 0.0;
        double years        = 0.0;
        boolean validSoFar  = true;

        // Get inputs:

        if (validSoFar == true)
        {
            principal = strToDouble (principalTextField, MIN_PRINCIPAL, MAX_PRINCIPAL, "Principal");
            if (principal < MIN_PRINCIPAL)
                validSoFar = false;
        }
            
        if (validSoFar == true)
        {
            interestRate = strToDouble (interestRateTextField, 0.1, 12, "Interest Rate");
            if (interestRate < 0.1)
                validSoFar = false;
        }

        if (validSoFar == true)
        {
            years = strToDouble (yearsTextField, 1, 5, "Years");
            if (years < 1)
                validSoFar = false;
        }

        if (validSoFar == true)
        {
            // Calculate: I = PNR/100 and Balance = P +I
            double interest = principal * interestRate * years / 100.0;
            double newBalance = principal + interest;

           // Display results:
           // Keep all calc results.  Show the latest at the top of the list.

           String resultStr = "$"       + String.format ("%,.2f", principal)    + 
                              " @ "     + String.format ("%,.2f", interestRate) + "%"             +
                              " for "   + String.format ("%,.1f", years)        + " year(s)"      +
                              " pays $" + String.format ("%,.2f", interest)     + " in interest " +
                              " and results in a balance of $" + String.format ("%,.2f", newBalance);

           outputTextArea.setText (resultStr + "\n" + outputTextArea.getText () );
        }
    }
    
}
