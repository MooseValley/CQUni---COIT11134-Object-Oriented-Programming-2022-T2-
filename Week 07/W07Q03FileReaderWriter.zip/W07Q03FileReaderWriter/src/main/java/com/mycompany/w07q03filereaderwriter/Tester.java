/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w07q03filereaderwriter;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class Tester 
{
    static ArrayList<Employee> employees = new ArrayList<>();
    
    public static void readFile (String fileNameStr) //throws Exception
    {
        try
        {
            Scanner scanner = new Scanner (new FileReader (fileNameStr));

            employees.clear(); // clears the arraylist

            while (scanner.hasNext() == true)
            {
                String idStr = scanner.nextLine();
                int id = Integer.parseInt (idStr);

                String name = scanner.nextLine();

                Employee emp = new Employee (id, name);

                employees.add (emp);
            }

            scanner.close();
        }
        catch (Exception err)
        {
            System.out.println ("File could NOT be read.");
        }       
    }
    
    public static void writeFile (String fileNameStr) //throws Exception
    {
        try
        {
            Formatter formatter = new Formatter (fileNameStr);

            for (Employee e : employees)
            {
                formatter.format ("%d\n%s\n", e.getId(), e.getName() );
            }

            formatter.close();
        }
        catch (Exception err)
        {
            System.out.println ("File could NOT be written.");
        }        
    }

    private static void displayData ()
    {
        for (int k = 0; k < employees.size(); k++)
            System.out.println (employees.get(k) );
    }
    
    public static void main(String[] args)
    {
        /*
        try
        {
            readFile ("staff.txt");
        }
        catch (Exception err)
        {
            System.out.println ("File could NOT be read.");
        }
        displayData();
        
        try
        {
            writeFile ("staff2.txt");
        }
        catch (Exception err)
        {
            System.out.println ("File could NOT be written.");
        }
        */

        readFile ("staff.txt");
        displayData();
        writeFile ("staff3.txt");
    }
    
}
