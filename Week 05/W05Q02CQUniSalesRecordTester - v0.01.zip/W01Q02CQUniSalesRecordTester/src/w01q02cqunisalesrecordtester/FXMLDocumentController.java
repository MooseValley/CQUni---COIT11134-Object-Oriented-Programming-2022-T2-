/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01q02cqunisalesrecordtester;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField costTextField;
    @FXML
    private TextField salesPriceTextField;
    @FXML
    private Button addButton;
    @FXML
    private Button statsButton;
    @FXML
    private Button exitButton;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addButtonHandler(ActionEvent event) {
    }

    @FXML
    private void statsButtonHandler(ActionEvent event) throws IOException 
    {
        Parent root = FXMLLoader.load(getClass().getResource("StatsScreenFXML.fxml"));
        
        Scene scene = new Scene(root);
        //Stage stage = new Stage ();
        Stage stage = (Stage)((Node) event.getSource() ).getScene().getWindow();
        
        stage.setScene(scene);
        stage.show();    
    }

    @FXML
    private void exitButtonHandler(ActionEvent event) {
    }
    
}
