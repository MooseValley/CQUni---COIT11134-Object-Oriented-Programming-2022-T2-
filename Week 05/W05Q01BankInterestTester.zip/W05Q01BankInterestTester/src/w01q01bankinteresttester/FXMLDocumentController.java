/*
Mike O's Extras / Homework:
* Create a class called BankInterest and create an object of this type when the Calculate button is clicked.
* Add the BankInterest object to an ArrayList of BankInterest objects.
* Use the ArrayList to display the data in the textarea
* Also display the number of BankInterest objects and the average interest calculated so far.


 */
package w01q01bankinteresttester;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField principalTextField;
    @FXML
    private TextField interestRateTextField;
    @FXML
    private Button calculateButton;
    @FXML
    private TextField yearsTextField;
    @FXML
    private TextArea outputTextArea;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void calculateButtonHandler(ActionEvent event) 
    {
        // Get inputs:
        double principal    = Double.parseDouble (principalTextField.getText() );
        double interestRate = Double.parseDouble (interestRateTextField.getText() );
        double years        = Double.parseDouble (yearsTextField.getText() );
                
        // Calculate: I = PNR/100 and Balance = P +I
        double interest = principal * interestRate * years / 100.0;
        double newBalance = principal + interest;
                
       // Display results:
       // Keep all calc results.  Show the latest at the top of the list.
       
       String resultStr = "$"       + String.format ("%,.2f", principal)    + 
                          " @ "     + String.format ("%,.2f", interestRate) + "%"             +
                          " for "   + String.format ("%,.1f", years)        + " year(s)"      +
                          " pays $" + String.format ("%,.2f", interest)     + " in interest " +
                          " and results in a balance of $" + String.format ("%,.2f", newBalance);
               
       outputTextArea.setText (resultStr + "\n" + outputTextArea.getText () );
                
    }
    
}
