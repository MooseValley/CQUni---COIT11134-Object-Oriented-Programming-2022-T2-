/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01q02cqunisalesrecordtester;

/**
 *
 * @author omalleym
 */
;
 
public class Product
{
    private String name;
    private double costPrice;
    private double soldPrice;

    public Product() {
     }

    public Product(String name, double costPrice, double soldPrice) 
    {
        // Data validation should go here ...
        // Should produce error messages and pass them back to the parent / calling class
        // and that parent / calling class should display the errors
        // We need more Exception Handling to do this ...
        // *** Hint: Assignment 2. ***
        
        /*
        try catch ...
        try catch ...
        try catch ...
        
        */
                                    
                                    
        
     this.name = name;
     this.costPrice = costPrice;
     this.soldPrice = soldPrice;
     }

     public String getName() {
     return name;
     }
     
     public void setName(String name) {
     this.name = name;
     }
     
     public double getCostPrice() {
     return costPrice;
     }
     
     public void setCostPrice(double costPrice) {
     this.costPrice = costPrice;
     }
     
     public double getSoldPrice() {
     return soldPrice;
     }
     
     public void setSoldPrice(double soldPrice) {
     this.soldPrice = soldPrice;
     }
     
     @Override
     public String toString() {
     return "Name :" + name + ", Cost Price=" + costPrice + ", SoldPrice=" + soldPrice;
     }
 
}
