/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01q02cqunisalesrecordtester;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField costTextField;
    @FXML
    private TextField salesPriceTextField;
    @FXML
    private Button addButton;
    @FXML
    private Button statsButton;
    @FXML
    private Button exitButton;
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addButtonHandler(ActionEvent event) 
    {
        String nameStr       = nameTextField.getText().trim();
        String costPriceStr  = costTextField.getText().trim();
        String salesPriceStr = salesPriceTextField.getText().trim();
        double costPrice     = 0.0;
        double salesPrice    = 0.0;
        boolean dataValid    = true;  
        
        if (dataValid == true)
        {
            if (nameStr.length() <= 2)
            {
                JOptionPane.showMessageDialog (null, "Error: Name must be at least 2 characters long.");
                dataValid = false;
            }
        }
        
        if (dataValid == true)
        {
            if (costPriceStr.length() == 0)
            {
                JOptionPane.showMessageDialog (null, "Error: Cost Price cannot be blank.");
                dataValid = false;
            }
            else
            {
                costPrice = Double.parseDouble (costPriceStr);
            }
        }
        
        if (dataValid == true)
        {
            if (salesPriceStr.length() == 0)
            {
                JOptionPane.showMessageDialog (null, "Error: Sales Price cannot be blank.");
                dataValid = false;
            }
            else
            {
                salesPrice = Double.parseDouble (salesPriceStr);
            }
        }
        
        if (dataValid == true)
        {
            // All data inputs are valid ... add the new Product to our productsArrayList.
            
            Product p = new Product (nameStr, costPrice, salesPrice);
            
            //W01Q02CQUniSalesRecordTester.productsArrayList.add (p);
            W01Q02CQUniSalesRecordTester.getArrayListProduct ().add (p);
            
            
            JOptionPane.showMessageDialog (null, "Success: new product added to database: " + "\n" + "* " + p.toString() );

            // Clear User Inputs
            nameTextField.setText("");
            costTextField.setText("");
            salesPriceTextField.setText("");
        }
 
    }

    @FXML
    private void statsButtonHandler(ActionEvent event) throws IOException 
    {
        /*
        Parent root = FXMLLoader.load(getClass().getResource("StatsScreenFXML.fxml"));
        
        Scene scene = new Scene(root);
        //Stage stage = new Stage ();
        Stage stage = (Stage)((Node) event.getSource() ).getScene().getWindow();
        
        stage.setScene(scene);
        stage.show();    
        */
        
        Utility.changeScene ("StatsScreenFXML.fxml", getClass(), event);
    }

    @FXML
    private void exitButtonHandler(ActionEvent event) 
    {
        Alert alert = new Alert (Alert.AlertType.CONFIRMATION, "Are you sure you want to Exit?");

        alert.showAndWait().ifPresent ( response -> 
            {
               if (response == ButtonType.OK) 
               {
                   Platform.exit();
               }
            });       
    }
    
}
