/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01q02cqunisalesrecordtester;

import java.io.IOException;
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author omalleym
 */
public class Utility 
{
    public static void changeScene (String sceneFXMLNameStr, Class parentClass, Event event) throws IOException
    {
        Parent root = FXMLLoader.load(parentClass.getResource(sceneFXMLNameStr));
        
        Scene scene = new Scene(root);
        //Stage stage = new Stage ();
        Stage stage = (Stage)((Node) event.getSource() ).getScene().getWindow();
        
        stage.setScene(scene);
        stage.show();          
    }
    
}
