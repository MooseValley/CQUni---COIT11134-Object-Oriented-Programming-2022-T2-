/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w01q02cqunisalesrecordtester;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author omalleym
 */
public class StatsScreenFXMLController implements Initializable {

    @FXML
    private Button closeButton;
    @FXML
    private TextArea outputTextArea;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        outputTextArea.setText("");

        //for (Product p: W01Q02CQUniSalesRecordTester.productsArrayList)
        for (Product p: W01Q02CQUniSalesRecordTester.getArrayListProduct() )
        {
            outputTextArea.appendText (p.toString() + "\n");
        }

        //outputTextArea.appendText ("\n" + W01Q02CQUniSalesRecordTester.productsArrayList.size() + " products found." + "\n");
        outputTextArea.appendText ("\n" + W01Q02CQUniSalesRecordTester.getArrayListProduct().size() + " products found." + "\n");
        
    }    

    @FXML
    private void closeButtonHandler(ActionEvent event) throws IOException 
    {
        /*
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        //Stage stage = new Stage ();
        Stage stage = (Stage)((Node) event.getSource() ).getScene().getWindow();
        
        stage.setScene(scene);
        stage.show();     
        */
        
        Utility.changeScene ("FXMLDocument.fxml", getClass(), event);
    }
    
}
